<nav class="blue darken-3">
    
    <div class="nav-wrapper">
        
      <ul id="nav-mobile" class="left">
          
        <li><a href="#about"><i class="material-icons left">subject</i>Docs</a></li>
          
        <li><a href="#hustle"><i class="material-icons left">swap_calls</i>Demo</a></li>
          
          <li class="hide-on-large-only">
                <a href="<?php echo DOWNLOADLINK;?>" target="_blank">
                    <i class="material-icons left">file_download</i>Download
                </a>
              
            </li>
          
      </ul>
        
        <ul class="right hide-on-med-and-down">
            
            <li>
                <a href="<?php echo DOWNLOADLINK;?>" target="_blank">
                    <i class="material-icons left">file_download</i>Download
                </a>
            </li>
            
        </ul>
        
    </div>
    
</nav>