<?php
/*
loading.php

placeholder file for when the submitConversion() function in geuza.js is running

*/
?>

<div class="loading-div blue-text" align="center">
    
    <i class="material-icons md-48">schedule</i>
    
    <p>Loading...</p>
    
</div>