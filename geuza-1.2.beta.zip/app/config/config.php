<?php

if(!defined('GEUZALINK')){define('GEUZALINK',"http://localhost:8014/geuza/1-2/");}//if

if(!defined('GEUZAVERSION')){define('GEUZAVERSION','1.2.beta');}//if

if(!defined('GEUZAPIKEY')){define('GEUZAPIKEY','a6e65616b0bbec6ea859b3a5e96a54f3');}//if

if(!defined('APPTITLE')){define('APPTITLE','Geuza');}//if

if(!defined('DEFAULTCURRENCY')){define('DEFAULTCURRENCY','KES');}//if

if(!defined('DECIMALS')){define('DECIMALS',3);}//if

if(!defined('MINIMUMAMOUNT')){define('MINIMUMAMOUNT',0.001);}//if

if(!defined('STEP')){define('STEP',0.001);}//if

if(!defined('COPYRIGHTINFO')){define('COPYRIGHTINFO','&copy; '.date("Y").' Amina Kombo');}

if(!defined('DOWNLOADLINK')){define('DOWNLOADLINK',"https://github.com/AminaKombo");}//if