<?php
/*
@const GEUZALINK -> link to main application
*/
if(!defined('GEUZALINK')){
    
    define('GEUZALINK',"");
    
}//if

/*
@const GEUZAVERSION -> version of current GEUZA distro
*/
if(!defined('GEUZAVERSION')){
    
    define('GEUZAVERSION','1.2.beta');

}//if

/*
@const APPTITLE -> title of application
*/
if(!defined('APPTITLE')){
    
    define('APPTITLE','Geuza');

}//if

/*
@const DEFAULTCURRENCY -> default currency code of application
*/
if(!defined('DEFAULTCURRENCY')){
    
    define('DEFAULTCURRENCY','KES');

}//if

/*
@const DECIMAILS -> number of decimal places to display for conversion
*/
if(!defined('DECIMALS')){
    
    define('DECIMALS',3);

}//if

/*
@const MINIMUMAMOUNT -> the least amount to compare against
*/
if(!defined('MINIMUMAMOUNT')){
    
    define('MINIMUMAMOUNT',0.001);

}//if

/*
@const STEP -> value to increment in the 'amount' inut field
*/
if(!defined('STEP')){
    
    define('STEP',0.001);

}//if

/*
@const COPYRIGHTINFO -> may be changed to your information
*/
if(!defined('COPYRIGHTINFO')){
    
    define('COPYRIGHTINFO','&copy; '.date("Y").' Amina Kombo');

}//if

/*
@const DOWNLOADLINK -> link to GEUZA download file. Keep it as it, or change it to your own.
*/
if(!defined('DOWNLOADLINK')){define('DOWNLOADLINK',"https://github.com/AminaKombo/Geuza");}//if