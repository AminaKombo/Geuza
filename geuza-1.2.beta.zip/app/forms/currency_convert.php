<?php
if(!isset($_SESSION)){session_start();}//if

$currencyModel=new \Geuza\Core\CurrencyModel();

$amount=1;

if(isset($_SESSION['grecover']['amount'])){$amount=floatval($_SESSION['grecover']['amount']);}//if

$from=DEFAULTCURRENCY;

if(isset($_SESSION['grecover']['from'])){$from=$_SESSION['grecover']['from'];}

$to="";

if(isset($_SESSION['grecover']['to'])){$to=$_SESSION['grecover']['to'];}
//var_dump($currencyModel);
?>
<form method="post">
    <div class="row">
        <div class="col s12 m3 l3">
            <label for="amount">Amount</label>
            <input type="number" min="<?php echo MINIMUMAMOUNT;?>" step="<?php echo STEP;?>" name="amount" id="amount" value="<?php echo $amount;?>" required/>
        </div>
        <div class="col s12 m3 l3">
            <label for="from">From</label>
            <select name="from" id="from" class="browser-default">
            <?php
                foreach($currencyModel->currencies as $currency){
                    echo "<option value='".$currency->code."' ";
                    if($currency->code==$from){
                        echo "selected='selected'";
                    }//if
                    echo ">".$currency->name."</option>";
                }//foreach
            ?>
            </select>
        </div>
        <div class="col s12 m3 l3">
            <label for="to">To</label>
            <select name="to" id="to" class="browser-default">
            <?php
                foreach($currencyModel->currencies as $currency){
                    echo "<option value='".$currency->code."' ";
                    if($currency->code==$to){
                        echo "selected='selected'";
                    }//if
                    echo ">".$currency->name."</option>";
                }//foreach
            ?>
            </select>
        </div>
        <div class="col s12 m3 l3" align="center"><label>Discover</label><br />
            
            
          <button class="btn blue waves-effect waves-light" type="submit" name="geuza">
            <i class="material-icons left">swap_calls</i> Convert
          </button>
        
            
        </div>
        
    </div>
</form>