<form method="post"><!--reverse things-->
    <input type="hidden" name="amount" value="<?php echo $app->amount;?>" />
    <input type="hidden" name="from" value="<?php echo $toCode;?>" />
    <input type="hidden" name="to" value="<?php echo $fromCode;?>"/>
    <div>
        <button type="submit" class="btn btn-large white black-text" name="geuza" title="swap">
        <i class="material-icons md-48 hide-on-med-and-down">swap_horiz</i>
        <i class="material-icons md-48 hide-on-large-only">swap_vert</i>
        </button>
    </div>
</form>