<?php
namespace Geuza\Core;

class CurrencyModel{
    
    var $currencies;
    
    public function __construct(){
       
        $this->currencies=$this->getCurrencies();
        
    }//constructor
    
    public function __destruct(){}//destructor
    
    private function getCurrencies(){
        
        $url="app".DS."data".DS."currencies.json";
        
        $data=file_get_contents($url);
        
        $currencies=json_decode($data);
        
        return $currencies;
        
    }//sgetCurrencies
    
}//CurrencyModel