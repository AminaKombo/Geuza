<?php
namespace Geuza\Core;

class Geuza{
    
    var $from="";
    
    var $to="";
    
    var $amount=1;
    
    var $conversionData=array();
    
    public function __construct(){
        
        if(isset($_POST['geuza'])){
            
            $this->conversionData=$this->convertCurrencies();
            
        }//if
        
    }//constructor
    
    public function __destruct(){}//destructor
    
    
    /*
    convertCurrencies() receives data from form post
    @return mixed[] data -> array of converted data
    */
    
    private function convertCurrencies(){
        
        $_SESSION['grecover']['from']=$_POST['from'];
        
        $_SESSION['grecover']['to']=$_POST['to'];
        
        $_SESSION['grecover']['amount']=$_POST['amount'];
        
        $this->from=urlencode($_POST['from']);
        
        $this->to=urlencode($_POST['to']);
        
        $this->amount=$_POST['amount'];
        
        $get=file_get_contents("https://www.google.com/finance/converter?a=".$this->amount."&from=".$this->from."&to=".$this->to);
        
        $get=explode("<span class=bld>",$get);
        if(isset($get[1])){
            
            $get=explode("</span>",$get[1]);
        
            $rate = preg_replace("/[^0-9\.]/", null, $get[0]);
        
            $converted_amount = $this->amount*$rate;
            
        }//if
        else{
            
            $rate=0;
            
            $converted_amount=0;
            
        }//else
        
        $data = array( 'rate' => $rate, 
                        'converted_amount' =>$converted_amount, 
                        'from_Currency' => strtoupper($this->from), 
                        'to_Currency' => strtoupper($this->to)
                    );
        
        return $data;
        
    }//convertCurrencies
    
}//geuza