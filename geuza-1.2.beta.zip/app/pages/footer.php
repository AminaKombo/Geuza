<div class="row blue darken-4 white-text footer">
    <div class="col m2 l2 hide-on-med-and-down">&nbsp;</div>
    <div class="col s12 m8 l8 blue darken-3">
        <div class="content">
            
            <div class="row">
                <div class="col s12 m6 l6">
                    <a href="<?php echo DOWNLOADLINK;?>" target="_blank" class="white-text" title="download it now!"><i class="material-icons left">file_download</i> Geuza <?php echo GEUZAVERSION;?></a>
                </div>
                <div class="col s12 m6 l6" align="right">
                     <a href="https://github.com/AminaKombo" target="_blank" class="white-text" title="See what else I've been doing."><?php echo COPYRIGHTINFO;?></a>
                </div>
            </div>
            
           </div>
    </div>
    <div class="col m2 l2 hide-on-med-and-down">&nbsp;</div>
</div>