<?php
$fromCode=DEFAULTCURRENCY;

if(isset($app->conversionData['from_Currency'])){
    $fromCode=$app->conversionData['from_Currency'];
}//if

$toCode="(Pick a currency, any currency.)";

if(isset($app->conversionData['to_Currency'])){
    $toCode=$app->conversionData['to_Currency'];
}//if

$convertedAmount=0;
if(isset($app->conversionData['converted_amount'])){
    $convertedAmount=$app->conversionData['converted_amount'];
}//if
?>
<div class="row">
    <div class="col s12 m5 l5">
        
        <div class="ge-amount" id="amount-div">
            <?php echo $app->amount;?>
        </div>
        <div class="ge-currency" id="from-curr-div"><?php echo $fromCode;?></div>
        <?php //echo "<div class='ge-amount'>".$app->amount."</div><div class='ge-currency'>".$app->conversionData['from_Currency']."</div>";
        
        ?>
    </div>
    <div class="col s12 m2 l2 md-48 grey-text" align="center">=
        <?php 
            if($convertedAmount>0){
                include "app".DS."forms".DS."swap_conversion.php";
            }//if
        
        ?>
        
        
    </div>
    <div class="col s12 m5 l5">
        <div class="ge-amount" id="result-div">
            <?php echo number_format($convertedAmount,DECIMALS);?>
        </div>
        <div class="ge-currency" id="to-curr-div">
            <?php echo $toCode;?>
        </div>
        <?php //echo "<div class='ge-amount'>".$app->conversionData['converted_amount']."</div><div class='ge-currency'>".$app->conversionData['to_Currency']."</div>";?>
    
    </div>
</div>   
<?php
 