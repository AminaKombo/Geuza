<div class="row blue darken-4 white-text footer">
    <div class="col m2 l2 hide-on-med-and-down">&nbsp;</div>
    <div class="col s12 m8 l8 blue darken-3" align="center">
        <div class="content">
        <h1><?php echo APPTITLE;?></h1>
            <a href="<?php echo DOWNLOADLINK;?>" target="_blank" class="btn blue white-text"><i class="large material-icons left">file_download</i> Download (on Github)</a>
        </div>
    </div>
    <div class="col m2 l2 hide-on-med-and-down">&nbsp;</div>
</div>