$(document).ready(function(){
    
    var minimum_amount=$('#minamt').val();
    
    $('#amount').on('change',function(){
        var ge_amount=$(this).val();
        if(ge_amount>=0.001){
            $('#amount-div').html(ge_amount);
        }//if
        else{
            $(this).val(0.001);
        }//else
    });
    
    $('#from').on('change',function(){
        var ge_code=$(this).val();
        $('#from-curr-div').html(ge_code);
    });
    
    $('#to').on('change',function(){
        var ge_tcode=$(this).val();
        $('#result-div').html('<small>click button</small>');
        $('#to-curr-div').html(ge_tcode);
    });
    
});