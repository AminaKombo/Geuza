<?php 
@session_start();
if(!defined('DS')){define('DS',DIRECTORY_SEPARATOR);}//if
require("app".DS."config".DS."config.php");

require_once(__DIR__.DS."vendor".DS."autoload.php");

//require("app".DS."core".DS."geuza.php");

$app=new \Geuza\Core\Geuza();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title><?php echo APPTITLE;?></title>
         <!--Import Google Icon Font-->
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="<?php echo GEUZALINK;?>public/css/materialize.min.css"  media="screen,projection"/>
        
        <link type="text/css" rel="stylesheet" href="<?php echo GEUZALINK;?>public/css/geuza.css" />

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        
    </head>
    <body>
        
        <?php include "app".DS."pages".DS."header.php";?>
        
        <div class="row grey lighten-3">
            <div class="col s12 m2 l2 hide-on-med-and-down">&nbsp;</div>
            <div class="col s12 m8 l8 grey lighten-4">
                
                <div class="stage-div" id="stage-div" align="center">
                <?php
                    
                    include "app".DS."pages".DS."stage.php";
                    
                    ?>
                </div>
                <hr />
                <div id="calc-div" class="action-div">
                    
                    <?php include "app".DS."forms".DS."currency_convert.php";?>
                    
                </div>
                <?php include "app".DS."pages".DS."about.php";?>
            </div>
            <div class="col s12 m2 l2 hide-on-med-and-down">&nbsp;</div>
        </div>
        
        <input type="hidden" id="minamt" value="<?php echo MINIMUMAMOUNT;?>" />
        
        <?php include "app".DS."pages".DS."footer.php";?>

<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="<?php echo GEUZALINK;?>public/js/materialize.min.js"></script>
        <script type="text/javascript" src="<?php echo GEUZALINK;?>public/js/geuza.js"></script>

</body>
</html>